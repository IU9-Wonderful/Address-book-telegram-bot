import asyncio
import os
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from aiogram.types import FSInputFile
from aiogram.utils.chat_action import ChatActionSender
from aiogram.utils.media_group import MediaGroupBuilder
import logging
from data import db_session
from data.__all_models import User, Place
from data.config import get_bot_token
from data.yandex_maps import get_image

# get bot token from "config.txt"
BOT_TOKEN = get_bot_token()

# init bot
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.DEBUG)
dp = Dispatcher()


# states
class Form(StatesGroup):
    no_state = State()
    add_address = State()
    right_question = State()
    people = State()
    find_user = State()
    num_info = State()
    num_find_user = State()


# function for /help
async def help_me(message):
    await message.answer("Этот бот поможет поделиться местоположением важных для вас мест с другими пользователями"
                         " (только с вашего разрешения, конечно же).")
    await message.answer("/start\n/info\n/add_address\n/get_friends_addresses")


# main function
async def main():
    # init bot
    bot = Bot(token=BOT_TOKEN)

    # init database
    db_session.global_init("db/address_book.sqlite")

    # start bot
    await dp.start_polling(bot)


# start function
@dp.message(Command('start'))
async def process_start_command(message: types.Message):
    # get user's id, first_name, last_name, username.
    user_id, first_name, last_name, uname = (message.from_user.id, message.from_user.first_name,
                                             message.from_user.last_name, message.from_user.username)

    # creating class User for user
    user = User()

    user.id = user_id
    user.first_name = first_name
    user.last_name = last_name
    user.username = uname

    # start communication with database
    db_sess = db_session.create_session()

    # flag is True if user already in database
    flag = False
    for u in db_sess.query(User).all():
        if u.id == user_id:
            flag = True

    # if user not in database
    # append new user to database
    if not flag:
        db_sess.add(user)

    # finish communication with database
    db_sess.commit()

    # answer for user
    await message.answer(f"Здравствуйте, {first_name} {last_name}!")

    # if user is new
    # write him/her help text
    if not flag:
        await help_me(message)


# help function
@dp.message(Command('help'))
async def process_help_command(message: types.Message):
    await help_me(message)



# info function
@dp.message(Command('info'))
async def process_start_command(message: types.Message, state: FSMContext) -> None:
    # get user's id, first_name, last_name, username.
    user_id, first_name, last_name, uname = (message.from_user.id, message.from_user.first_name,
                                             message.from_user.last_name, message.from_user.username)

    # start communication with database
    db_sess = db_session.create_session()

    # flag is True if user already in database
    flag = False
    for u in db_sess.query(User).all():
        if u.id == user_id:
            flag = True

    # if user not in database
    # write him/her about it
    if not flag:
        await message.answer("Кажется вас нет в базе данных. Воспользуйтесь командой /start.")

    # if user in database
    # show him/her his/her places
    else:
        # message
        text = "Ваши места и пользователи, которые могут их увидеть."

        # no places in database flag
        clear = True

        # number
        p = 1
        # all places in database
        for place in db_sess.query(Place).all():
            if place.author == user_id:  # if place by user who used /info
                # not clear
                clear = False

                # update message
                if place.visible_for:
                    # users who can see this place
                    text += f"\n{p}. {place.address}\n   Видят: {place.visible_for}"
                else:
                    # if nobody can't see this place
                    text += f"\n{p}. {place.address}\n   Это место скрыто."

                # number up
                p += 1

        # if no places in database
        if clear:
            text = "Вы пока что не добавили ни одного места в базу данных."

        # send response
        await message.answer(text)
        await message.answer("Для редактирования места введите его номер.")
        await message.answer("/back для остановки.")
        await state.set_state(Form.num_info)

    # finish communication with database
    db_sess.commit()


# add address function
@dp.message(Command('add_address'))
async def process_start_command(message: types.Message, state: FSMContext) -> None:
    # get user's id, first_name, last_name, username.
    user_id, first_name, last_name, uname = (message.from_user.id, message.from_user.first_name,
                                             message.from_user.last_name, message.from_user.username)

    # start communication with database
    db_sess = db_session.create_session()

    # flag is True if user already in database
    flag = False
    for u in db_sess.query(User).all():
        if u.id == user_id:
            flag = True

    # if user not in database
    # write him/her about it
    if not flag:
        await message.answer("Кажется вас нет в базе данных. Воспользуйтесь командой /start.")

    # if user in database
    # show him/her his/her places
    else:
        # message
        await message.answer("Напишите адрес: (/back для отмены)")
        await state.set_state(Form.add_address)

    # finish communication with database
    db_sess.commit()


# get friend's addresses function
@dp.message(Command('get_friends_addresses'))
async def process_start_command(message: types.Message, state: FSMContext) -> None:
    # get user's id, first_name, last_name, username.
    user_id, first_name, last_name, uname = (message.from_user.id, message.from_user.first_name,
                                             message.from_user.last_name, message.from_user.username)

    # start communication with database
    db_sess = db_session.create_session()

    # flag is True if user already in database
    flag = False
    for u in db_sess.query(User).all():
        if u.id == user_id:
            flag = True

    # if user not in database
    # write him/her about it
    if not flag:
        await message.answer("Кажется вас нет в базе данных. Воспользуйтесь командой /start.")

    # if user in database
    # show him/her his/her places
    else:
        # message
        await message.answer("Напишите имя пользователя (@username), адреса которого хотите узнать: (/back для отмены)")
        await state.set_state(Form.find_user)

    # finish communication with database
    db_sess.commit()


# back function
@dp.message(Command('back'))
async def process_help_command(message: types.Message, state: FSMContext) -> None:
    # gets current state
    current_state = await state.get_state()

    # if it is not None
    if current_state is not None:
        # state will be cleared
        await state.clear()

        # message for user
        await message.answer("Отменено (Остановлено).")

        # user id
        user_id = message.from_user.id

        # remove "images/{user_id}.txt"
        if os.path.exists(f'images\\{user_id}.txt'):
            os.remove(f'images\\{user_id}.txt')


# function for messages from user
@dp.message()
async def echo_message(message: types.Message, state: FSMContext) -> None:
    # gets current state
    current_state = await state.get_state()

    # if user want to add new address    (/add_address)
    if current_state == Form.add_address:
        address = message.text
        async with ChatActionSender.upload_photo(bot=message.bot, chat_id=message.chat.id):
            user_id = message.from_user.id

            # start communication with database
            db_sess = db_session.create_session()

            # flag is True if place already in database
            flag = False
            for p in db_sess.query(Place).all():
                if p.author == user_id and p.address == address:
                    flag = True

            # if place in database
            # write user about it
            if flag:
                await message.answer("Это место уже есть в базе данных.")
            else:
                # save map file as "images/{user_id}.png"
                get_image(address, user_id)

                # save address in "images/{user_id}.txt"
                f = open(f"images\\{user_id}.txt", "w", encoding="utf-8")
                f.write(address + "\n")
                f.close()

                # creating media group
                media = MediaGroupBuilder(caption='Верно? (Да/Нет)')
                # add "images/{user_id}.png"
                media.add_photo(FSInputFile(f'images/{user_id}.png'), '')
                # send media group to user
                await message.reply_media_group(media=media.build())

                # remove "images/{user_id}.png"
                os.remove(f'images\\{user_id}.png')

                # right? (yes/No)
                await state.set_state(Form.right_question)

    # Right? (Yes/No)    (/add_address)
    elif current_state == Form.right_question:
        # "Yes" answer
        if message.text.lower().lstrip().rstrip().replace('.', '').replace(',', '').replace('!',
                    '').replace('?', '').replace('"', '').replace("'", '') == 'да':

            user_id = message.from_user.id

            # read address from "images/{user_id}.txt"
            f = open(f"images\\{user_id}.txt", "r", encoding="utf-8")
            address = f.read().rstrip()
            f.close()

            # start communication with database
            db_sess = db_session.create_session()

            # new place
            place = Place()
            place.author = user_id
            place.address = address

            # add place to the database
            db_sess.add(place)

            # end communication with database
            db_sess.commit()

            # messages for user
            await message.answer(
                'Теперь вводите имена (Имя пользователя - username) пользователей, которые смогут увидеть это место.')
            await message.answer('/back для остановки.')

            # "people input" state
            await state.set_state(Form.people)

        # "No" answer
        elif message.text.lower().lstrip().rstrip().replace('.', '').replace(',', '').replace('!',
                    '').replace('?', '').replace('"', '').replace("'", '') == 'нет':

            # clear state
            await state.clear()

            # message for user
            await message.answer("Отменено (Остановлено).")

        # unknown answer
        else:
            # repeat the answer
            await message.answer("'Верно? (Да/Нет)")

    # inputting people username    (/add_address)
    elif current_state == Form.people:
        # user id
        user_id = message.from_user.id

        # read address from "images/{user_id}.txt"
        f = open(f"images\\{user_id}.txt", "r", encoding="utf-8")
        address = f.read().rstrip()
        f.close()

        # inputted username
        user = message.text

        # start communication with database
        db_sess = db_session.create_session()

        # get place id
        id_place = None
        for p in db_sess.query(Place).all():
            if p.author == user_id and p.address == address:
                id_place = p.id

        # get users who can see this place
        place = db_sess.query(Place).get(id_place)
        people = place.visible_for

        # if nobody there
        if people is None:
            people = user

        # if people in database
        else:
            ppl = people.split(',')
            ppl.append(user)
            people = ','.join(ppl)

        # update database
        place.visible_for = people

        # end communication with database
        db_sess.commit()

        # message for user
        await message.answer(f"Теперь @{user} может видеть это место.")

    # inputting friends username    (/get_friends_addresses)
    elif current_state == Form.find_user:
        # inputted username
        user = message.text

        # id of user who use bot
        user_id = message.from_user.id

        # start communication with database
        db_sess = db_session.create_session()

        # get from database id of user with @username like inputted
        id_ = None
        for u in db_sess.query(User).all():
            if u.username == user:
                id_ = u.id
                break

        # if user not in database
        if id_ is None:
            await message.answer(f"Пользователя @{user} нет в базе данных. Значит, он никогда не использовал команду "
                                 f"/start в этом боте")

        # if user in database
        else:
            # message
            text = f"Места пользователя @{user}, которые вы можете увидеть:"

            # no places in database flag
            clear = True

            # number
            p_n = 1
            for p in db_sess.query(Place).all():
                if p.author == id_ and user_id in p.visible_for.split(','):
                    clear = False
                    text += f"\n{p_n}. {p.address}"
                    p_n += 1

            # if no places in database
            if clear:
                text = f"Пользователь @{user} ещё не разрешил вам увидеть ни одно из своих мест."

            # send response
            await message.answer(text)
            await message.answer("Для просмотра карты места введите его номер.")
            await message.answer("/back для остановки.")
            await state.set_state(Form.num_find_user)

        # finish communication with database
        db_sess.commit()

    pass


if __name__ == '__main__':
    asyncio.run(main())

