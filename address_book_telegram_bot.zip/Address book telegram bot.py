import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
import logging
from data import db_session
from data.__all_models import User, Place

BOT_TOKEN = ''

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.DEBUG)
dp = Dispatcher()


class Form(StatesGroup):
    no_state = State()
    add_address = State()
    right_answer = State()


async def help_me(message):
    await message.answer("Этот бот поможет поделиться местоположением важных для вас мест с другими пользователями"
                         " (только с вашего разрешения, конечно же).")
    await message.answer("/start\n/info")


async def main():
    bot = Bot(token=BOT_TOKEN)
    db_session.global_init("db/address_book.sqlite")
    await dp.start_polling(bot)

# start function
@dp.message(Command('start'))
async def process_start_command(message: types.Message):
    # get user's id, first_name, last_name, username.
    user_id, first_name, last_name, uname = (message.from_user.id, message.from_user.first_name,
                                             message.from_user.last_name, message.from_user.username)

    # creating class User for user
    user = User()

    user.id = user_id
    user.first_name = first_name
    user.last_name = last_name
    user.username = uname

    # start communication with database
    db_sess = db_session.create_session()

    # flag is True if user already in database
    flag = False
    for u in db_sess.query(User).all():
        if u.id == user_id:
            flag = True

    # if user not in database
    # append new user to database
    if not flag:
        db_sess.add(user)

    # finish communication with database
    db_sess.commit()

    # answer for user
    await message.answer(f"Здравствуйте, {first_name} {last_name}!")

    # if user is new
    # write him/her help text
    if not flag:
        await help_me(message)


# help function
@dp.message(Command('help'))
async def process_help_command(message: types.Message):
    await help_me(message)



# info function
@dp.message(Command('info'))
async def process_start_command(message: types.Message):
    # get user's id, first_name, last_name, username.
    user_id, first_name, last_name, uname = (message.from_user.id, message.from_user.first_name,
                                             message.from_user.last_name, message.from_user.username)

    # start communication with database
    db_sess = db_session.create_session()

    # flag is True if user already in database
    flag = False
    for u in db_sess.query(User).all():
        if u.id == user_id:
            flag = True

    # if user not in database
    # write him/her about it
    if not flag:
        await message.answer("Кажется вас нет в базе данных. Воспользуйтесь командой /start.")

    # if user in database
    # show him/her his/her places
    else:
        # message
        text = "Ваши места и пользователи, которые могут их увидеть."

        # no places in database flag
        clear = True

        # all places in database
        for place in db_sess.query(Place).all():
            if place.author == user_id:  # if place by user who used /info
                # not clear
                clear = False

                # update message
                text += f"\n{place.address}\nВидят: {place.visible_for}"

        # if no places in database
        if clear:
            text = "Вы пока что не добавили ни одного места в базу данных."

        # send response
        await message.answer(text)

    # finish communication with database
    db_sess.commit()


# add address function
@dp.message(Command('add_address'))
async def process_start_command(message: types.Message, state: FSMContext) -> None:
    # get user's id, first_name, last_name, username.
    user_id, first_name, last_name, uname = (message.from_user.id, message.from_user.first_name,
                                             message.from_user.last_name, message.from_user.username)

    # start communication with database
    db_sess = db_session.create_session()

    # flag is True if user already in database
    flag = False
    for u in db_sess.query(User).all():
        if u.id == user_id:
            flag = True

    # if user not in database
    # write him/her about it
    if not flag:
        await message.answer("Кажется вас нет в базе данных. Воспользуйтесь командой /start.")

    # if user in database
    # show him/her his/her places
    else:
        # message
        await message.answer("Напишите адрес: (/back для отмены)")
        await state.set_state(Form.add_address)

    # finish communication with database
    db_sess.commit()


# back function
@dp.message(Command('back'))
async def process_help_command(message: types.Message, state: FSMContext) -> None:
    # gets current state
    current_state = await state.get_state()

    # if it is not None
    if current_state is not None:
        # state will be cleared
        await state.clear()

        # message for user
        await message.answer("Отменено")



# function for messages from user
@dp.message()
async def echo_message(message: types.Message, state: FSMContext) -> None:
    # gets current state
    current_state = await state.get_state()

    # if user want to add new address
    if current_state == Form.add_address:
        address = message.text
        await message.answer(address)


if __name__ == '__main__':
    asyncio.run(main())

