import os


def get_bot_token():
    file = os.getcwd() + '/config.txt'
    f = open(file, 'r', encoding='utf-8')
    text = f.readlines()[0].split('\t')[1].rstrip()
    f.close()
    return text[:]


def get_yandex_maps_apikey():
    file = os.getcwd() + '/config.txt'
    f = open(file, 'r', encoding='utf-8')
    text = f.readlines()[1].split('\t')[1].rstrip()
    f.close()
    return text[:]


def get_geocoder_apikey():
    file = os.getcwd() + '/config.txt'
    f = open(file, 'r', encoding='utf-8')
    text = f.readlines()[2].split('\t')[1].rstrip()
    f.close()
    return text[:]
