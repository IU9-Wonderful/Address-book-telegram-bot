import sys
import requests
from data.config import get_yandex_maps_apikey, get_geocoder_apikey


def geocoder(address):
    try:
        url = "https://geocode-maps.yandex.ru/1.x/"
        params = {
            "apikey": get_geocoder_apikey(),
            'geocode': address,
            'format': 'json'
        }
        data = requests.get(url, params).json()
        coordinates_str = data['response']['GeoObjectCollection'][
            'featureMember'][0]['GeoObject']['Point']['pos']
        long, lat = map(float, coordinates_str.split())
        return long, lat
    except Exception as e:
        return e


def get_map(long, lat, name):
    server_address = 'https://static-maps.yandex.ru/v1?'
    api_key = get_yandex_maps_apikey()
    ll_spn = f'll={long},{lat}&spn=0.002,0.002'

    map_request = f"{server_address}{ll_spn}&apikey={api_key}"
    response = requests.get(map_request)

    if not response:
        print("Ошибка выполнения запроса:")
        print(map_request)
        print("Http статус:", response.status_code, "(", response.reason, ")")
        sys.exit(1)

    map_file = f"images/{name}.png"
    with open(map_file, "wb") as file:
        file.write(response.content)


def get_image(address, name):
    a1, a2 = geocoder(address)
    get_map(a1, a2, name)


def get_link(address):
    a, b = geocoder(address)
    return f"https://yandex.ru/maps/?ll={a}%2C{b}&mode=search&sll={a}%2C{b}&text={b}%2C{a}&z=16"
